using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagrams
{
    public class Worksheet
    {
    }

    public class CopyOfWorksheet
    {
    }
}
